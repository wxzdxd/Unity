using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class img_manager : MonoBehaviour
{

    public List<Texture2D> allTex2d = new List<Texture2D>();
    public RawImage img;
    int i = 0;
    public void next_img()
    {
        if (i >= allTex2d.Count - 1)
        {
            return;
        }
        else
        {
            img.GetComponent<RawImage>().texture = allTex2d[i + 1];
            i++;
        }
    }
    public void pre_img()
    {
        if (i == 0)
        {
            return;
        }
        else
        {
            img.GetComponent<RawImage>().texture = allTex2d[i - 1];
            i--;
        }
    }
    public void to_home()
    {
        img.GetComponent<RawImage>().texture = allTex2d[0];
        i = 0;
    }
    private void Start()
    {
        img.GetComponent<RawImage>().texture = allTex2d[i];
    }


}
